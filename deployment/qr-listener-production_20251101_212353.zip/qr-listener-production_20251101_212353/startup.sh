#!/bin/bash

# QR Listener Startup Script for A2 Hosting
# This script preserves existing database data when deploying updates
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }

echo "🚀 Starting QR Listener Application"
echo "===================================="

# Create directories
mkdir -p certbot/conf certbot/www logs

# Check Docker
if ! docker info > /dev/null 2>&1; then
    print_error "Docker is not running"
    exit 1
fi

# Stop and remove old containers with same names (preserves volumes)
print_status "Cleaning up old containers (preserves data)..."
docker stop qr-listener-redis-prod qr-listener-postgres-prod qr-listener-backend-prod qr-listener-frontend-prod qr-listener-nginx-prod qr-listener-certbot-prod 2>/dev/null || true
docker rm qr-listener-redis-prod qr-listener-postgres-prod qr-listener-backend-prod qr-listener-frontend-prod qr-listener-nginx-prod qr-listener-certbot-prod 2>/dev/null || true

# Check if database volume exists, create if it doesn't
VOLUME_NAME="qr_listener_postgres_data"
if docker volume ls | grep -q "$VOLUME_NAME"; then
    print_status "📦 Found existing database volume: $VOLUME_NAME"
    print_warning "⚠️  Existing database data will be preserved"
    print_status "   All your QR codes and publications are safe!"
else
    print_status "📦 Creating new database volume: $VOLUME_NAME"
    print_status "   (First deployment - database will be initialized)"
    docker volume create $VOLUME_NAME
fi

# Start services (this will reuse existing volumes if they exist)
print_status "Starting services..."
print_warning "⚠️  Using 'docker-compose up -d' which preserves volumes and existing data"
print_warning "⚠️  Data will NOT be lost - volumes persist across deployments"
docker-compose up -d --remove-orphans

# Wait for services
print_status "Waiting for services to be ready..."
sleep 30

# Show status
docker-compose ps

print_success "✅ Application started!"
print_status "Access at: http://graceshoppee.tech:8080"
print_status "  - Admin Dashboard: http://graceshoppee.tech:8080/dashboard"
print_status "  - Content Publisher: http://graceshoppee.tech:8080/publisher/dashboard"
print_success "💾 Database data is preserved from previous deployment"
