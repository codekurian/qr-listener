#!/bin/bash

# QR Listener Monitoring Script
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

case "${1:-status}" in
    "status")
        echo "📊 Container Status:"
        docker-compose ps
        echo ""
        echo "📈 Resource Usage:"
        docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}"
        ;;
    "logs")
        docker-compose logs -f ${2:-}
        ;;
    "restart")
        docker-compose restart ${2:-}
        ;;
    "health")
        echo "🏥 Health Check:"
        curl -f http://localhost:8081/api/qr/health && echo "✅ Backend: Healthy" || echo "❌ Backend: Unhealthy"
        curl -f http://localhost:3000 > /dev/null 2>&1 && echo "✅ Frontend: Healthy" || echo "❌ Frontend: Unhealthy"
        ;;
    *)
        echo "Usage: $0 [status|logs|restart|health] [service]"
        ;;
esac
