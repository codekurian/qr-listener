# QR Listener Production Deployment Package

## Features Included

- ✅ **QR Code Management**: Generate, manage, and track QR codes
- ✅ **Content Publisher**: Create beautiful biographies and family stories
  - Multi-step publication wizard
  - Photo upload and gallery
  - Rich text editor
  - Public viewing pages
  - Social sharing

## Quick Start

1. Extract the package:
   ```bash
   unzip qr-listener-production_*.zip
   cd qr-listener-production_*
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Start the application:
   ```bash
   ./startup.sh
   ```

## Access

- **Main Site**: http://graceshoppee.tech:8080
- **Admin Dashboard**: http://graceshoppee.tech:8080/dashboard
- **Content Publisher**: http://graceshoppee.tech:8080/publisher/dashboard
- **Backend API**: http://graceshoppee.tech:8080/api

## Management

- Check status: `./monitor.sh status`
- View logs: `./monitor.sh logs [service]`
- Restart: `./monitor.sh restart [service]`
- Health check: `./monitor.sh health`

## Data Preservation

⚠️ **IMPORTANT**: Database data is automatically preserved across deployments!

- Docker volumes persist your data
- The `postgres_data` volume survives container restarts
- QR codes and publications are preserved automatically

## Ports

- Nginx HTTP: 8080
- Nginx HTTPS: 8443
- Backend: 8081
- Frontend: 3000
- PostgreSQL: 5432
- Redis: 6379
