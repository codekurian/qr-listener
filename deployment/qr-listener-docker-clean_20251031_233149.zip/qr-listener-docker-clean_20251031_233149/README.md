# QR Listener Deployment Package

## Quick Start

1. Extract the package:
   ```bash
   unzip qr-listener-docker-clean_*.zip
   cd qr-listener-docker-clean_*
   ```

2. Make scripts executable:
   ```bash
   chmod +x *.sh
   ```

3. Start the application:
   ```bash
   ./startup.sh
   ```

## Access

- Frontend: http://graceshoppee.tech:8080
- Backend API: http://graceshoppee.tech:8080/api

## Management

- Check status: `./monitor.sh status`
- View logs: `./monitor.sh logs [service]`
- Restart: `./monitor.sh restart [service]`
- Health check: `./monitor.sh health`

## Ports

- Nginx HTTP: 8080
- Nginx HTTPS: 8443
- Backend: 8081
- Frontend: 3000
- PostgreSQL: 5432
- Redis: 6379
