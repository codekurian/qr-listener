#!/bin/bash

# QR Listener Startup Script for A2 Hosting
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "🚀 Starting QR Listener Application"
echo "===================================="

# Create directories
mkdir -p certbot/conf certbot/www logs

# Check Docker
if ! docker info > /dev/null 2>&1; then
    print_error "Docker is not running"
    exit 1
fi

# Start services
print_status "Starting services..."
docker-compose up -d

# Wait for services
print_status "Waiting for services to be ready..."
sleep 30

# Show status
docker-compose ps

print_success "✅ Application started!"
print_status "Access at: http://graceshoppee.tech:8080"
